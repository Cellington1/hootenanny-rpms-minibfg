var hierarchy =
[
    [ "FileGDBAPI::ByteArray", "class_file_g_d_b_a_p_i_1_1_byte_array.html", null ],
    [ "FileGDBAPI::EnumRows", "class_file_g_d_b_a_p_i_1_1_enum_rows.html", null ],
    [ "FileGDBAPI::Envelope", "class_file_g_d_b_a_p_i_1_1_envelope.html", null ],
    [ "FileGDBAPI::FieldDef", "class_file_g_d_b_a_p_i_1_1_field_def.html", null ],
    [ "FileGDBAPI::FieldInfo", "class_file_g_d_b_a_p_i_1_1_field_info.html", null ],
    [ "FileGDBAPI::Geodatabase", "class_file_g_d_b_a_p_i_1_1_geodatabase.html", null ],
    [ "FileGDBAPI::GeometryDef", "class_file_g_d_b_a_p_i_1_1_geometry_def.html", null ],
    [ "FileGDBAPI::IndexDef", "class_file_g_d_b_a_p_i_1_1_index_def.html", null ],
    [ "FileGDBAPI::Row", "class_file_g_d_b_a_p_i_1_1_row.html", null ],
    [ "FileGDBAPI::ShapeBuffer", "class_file_g_d_b_a_p_i_1_1_shape_buffer.html", [
      [ "FileGDBAPI::MultiPartShapeBuffer", "class_file_g_d_b_a_p_i_1_1_multi_part_shape_buffer.html", null ],
      [ "FileGDBAPI::MultiPatchShapeBuffer", "class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer.html", null ],
      [ "FileGDBAPI::MultiPointShapeBuffer", "class_file_g_d_b_a_p_i_1_1_multi_point_shape_buffer.html", null ],
      [ "FileGDBAPI::PointShapeBuffer", "class_file_g_d_b_a_p_i_1_1_point_shape_buffer.html", null ]
    ] ],
    [ "FileGDBAPI::SpatialReference", "class_file_g_d_b_a_p_i_1_1_spatial_reference.html", null ],
    [ "FileGDBAPI::Table", "class_file_g_d_b_a_p_i_1_1_table.html", null ]
];