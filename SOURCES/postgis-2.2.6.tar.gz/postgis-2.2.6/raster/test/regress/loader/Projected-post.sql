TRUNCATE spatial_ref_sys;
-- should this be done automatically ?
-- "loadedrast" is removed automatically !
DROP TABLE o_2_loadedrast;
